package com.example.deezerproyecto.models

data class Usuario(
    val uid: String = "",
    val nombre: String = "",
    val correo: String = "",
    val imagenPerfil: String = ""
)
