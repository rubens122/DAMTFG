package com.example.deezerproyecto.models

data class Usuario(
    var uid: String = "",
    var nombre: String = "",
    var correo: String = "",
    var imagenPerfil: String = ""
)
