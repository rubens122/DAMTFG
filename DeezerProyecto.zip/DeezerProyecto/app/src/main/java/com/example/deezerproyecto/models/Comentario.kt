package com.example.deezerproyecto.models

data class Comentario(
    val id: String = "",
    val texto: String = "",
    val autor: String = "",
    val timestamp: Long = 0L
)

